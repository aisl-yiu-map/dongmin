import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ExcelReader {

    public static void main(String[] args) throws IOException {
        // 엑셀 파일 경로 설정
        FileInputStream fis = new FileInputStream(new File("C:\\Desktop\\study\\AISL 네비게이션의 사본.xlsx"));
        Workbook workbook = new XSSFWorkbook(fis);  // XSSFWorkbook 사용 (xlsx 형식)
        Sheet sheet = workbook.getSheetAt(0); // 첫 번째 시트 선택

        // 엑셀 시트의 모든 행을 출력
        for (Row row : sheet) {
            for (Cell cell : row) {
                // 셀의 데이터를 출력
                switch (cell.getCellType()) {
                    case STRING:
                        System.out.print(cell.getStringCellValue() + "\t");
                        break;
                    case NUMERIC:
                        System.out.print(cell.getNumericCellValue() + "\t");
                        break;
                    case BOOLEAN:
                        System.out.print(cell.getBooleanCellValue() + "\t");
                        break;
                    default:
                        System.out.print("Unknown\t");
                        break;
                }
            }
            System.out.println(); // 행 끝에서 줄 바꿈
        }

        // 리소스 정리
        fis.close();
        workbook.close();
    }
}
