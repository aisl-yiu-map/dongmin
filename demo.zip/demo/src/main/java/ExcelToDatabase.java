import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class ExcelToDatabase {

    public static void main(String[] args) throws Exception {
        // 엑셀 파일 경로
        FileInputStream fis = new FileInputStream(new File("C:\\Desktop\\study\\AISL 네비게이션의 사본.xlsx"));
        Workbook workbook = new XSSFWorkbook(fis);  // XSSFWorkbook 사용 (xlsx 형식)
        Sheet sheet = workbook.getSheetAt(0); // 첫 번째 시트 선택

        // MySQL 연결 정보
        String url = "jdbc:mysql://localhost:3306/demo"; // 데이터베이스 URL
        String username = "root";  // 데이터베이스 사용자 이름
        String password = "1234";  // 데이터베이스 비밀번호

        // 데이터베이스 연결
        Connection connection = DriverManager.getConnection(url, username, password);

        // SQL INSERT 문
        String sql = "INSERT INTO building_classrooms (building_name, classroom_name) VALUES (?, ?)";
        PreparedStatement statement = connection.prepareStatement(sql);

        // 엑셀 파일 데이터를 읽어 MySQL로 삽입
        for (Row row : sheet) {
            if (row.getRowNum() == 0) continue; // 헤더를 무시 (첫 번째 행)

            String buildingName = row.getCell(0).getStringCellValue();
            String classroomName = row.getCell(1).getStringCellValue();

            // 데이터 삽입
            statement.setString(1, buildingName);
            statement.setString(2, classroomName);
            statement.executeUpdate();
        }

        // 리소스 정리
        statement.close();
        connection.close();
        workbook.close();
        fis.close();

        System.out.println("엑셀 데이터를 MySQL 데이터베이스에 삽입했습니다.");
    }
}
