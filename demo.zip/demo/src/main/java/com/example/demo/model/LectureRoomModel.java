package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
public class LectureRoomModel {

    @Id
    private Long id;
    private String name;

    @ManyToOne
    @JoinColumn(name = "building_id")  // 외래 키 컬럼 이름을 지정
    private BuildingModel building;  // Building과 연관 관계 (ManyToOne)

    // getLatitude()와 getLongitude() 메서드 추가
    @Getter
    private Double latitude;  // 강의실 위도
    @Getter
    private Double longitude; // 강의실 경도

    @Getter
    private String lectureRoomNumber;

    // 기본 생성자
    public LectureRoomModel() {}

    // 생성자
    public LectureRoomModel(Long id, String name, BuildingModel building, Double latitude, Double longitude, String lectureRoomNumber) {
        this.id = id;
        this.name = name;
        this.building = building;
        this.latitude = latitude;
        this.longitude = longitude;
        this.lectureRoomNumber = lectureRoomNumber;

    }

}
