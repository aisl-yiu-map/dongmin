package com.example.demo.repository;

import com.example.demo.model.BuildingModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;


public interface buildingRepository extends JpaRepository<BuildingModel, Long> {
    // 특정 건물의 좌표 조회 (위치는 x, y로 반환)
    Optional<BuildingModel> findById(Long id);
}
