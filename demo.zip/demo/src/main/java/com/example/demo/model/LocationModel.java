package com.example.demo.model; // 얜 그냥 기본 좌표 조회용

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class LocationModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    private Double x; // X 좌표
    private Double y; // Y 좌표
}
