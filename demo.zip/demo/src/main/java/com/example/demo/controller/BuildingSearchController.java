package com.example.demo.controller;

import com.example.demo.model.BuildingModel;
import com.example.demo.model.SearchModel;

import com.example.demo.service.BuildingSearchService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/search/building")
public class BuildingSearchController {

    private final BuildingSearchService searchService;

    public BuildingSearchController(BuildingSearchService searchService) {
        this.searchService = searchService;
    }

    @GetMapping("/{buildingName}")
    public ResponseEntity<SearchModel> searchBuildingByName(@PathVariable String buildingName) {
        BuildingModel building = searchService.searchBuildingByName(buildingName);
        if (building == null) {
            return ResponseEntity.notFound().build();
        }

        // Building 정보만 반환 (lectureRoom 정보는 없으므로 null 처리)
        SearchModel searchModel = new SearchModel(
                null,  // 강의실 정보는 없으므로 null
                building.getName(),
                building.getX(),   // 수정된 부분
                building.getY()    // 수정된 부분
        );
        return ResponseEntity.ok(searchModel);
    }
}
