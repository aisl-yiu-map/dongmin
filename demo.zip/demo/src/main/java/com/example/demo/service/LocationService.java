package com.example.demo.service; // 얜 그냥 기본 좌표 조회용

import com.example.demo.model.LocationModel;
import com.example.demo.repository.LocationRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LocationService {
    private final LocationRepository locationRepository;

    public LocationService(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }

    public List<LocationModel> getAllLocations() {
        return locationRepository.findAll();
    }

    public LocationModel getLocationById(Long id) {
        return locationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Location not found with id: " + id));
    }

    public LocationModel saveLocation(LocationModel locationModel) {
        return locationRepository.save(locationModel);
    }

    public LocationModel updateLocation(Long id, LocationModel updatedLocation) {
        LocationModel locationModel = getLocationById(id);
        locationModel.setName(updatedLocation.getName());
        locationModel.setX(updatedLocation.getX());
        locationModel.setY(updatedLocation.getY());
        return locationRepository.save(locationModel);
    }

    public void deleteLocation(Long id) {
        locationRepository.deleteById(id);
    }
}
