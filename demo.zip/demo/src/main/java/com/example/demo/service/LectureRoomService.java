package com.example.demo.service;


import org.springframework.stereotype.Service;
import java.util.List;

import com.example.demo.model.LectureRoomModel;


@Service
public class LectureRoomService {
    private final com.example.demo.repository.lectureRoomRepository lectureRoomRepository;

    public LectureRoomService(com.example.demo.repository.lectureRoomRepository lectureRoomRepository) {
        this.lectureRoomRepository = lectureRoomRepository;
    }

    // 특정 건물에 속한 모든 강의실 조회
    public List<LectureRoomModel> getLectureRoomsByBuildingId(Long buildingId) {
        return lectureRoomRepository.findByBuildingId(buildingId);
    }

    // 특정 강의실 ID로 정보 조회
    public LectureRoomModel getLectureRoomById(Long id) {
        return lectureRoomRepository.findById(id).orElseThrow(() -> new RuntimeException("LectureRoom not found"));
    }

    // 새로운 강의실 정보 저장
    public LectureRoomModel saveLectureRoom(LectureRoomModel lectureRoomModel) {
        return lectureRoomRepository.save(lectureRoomModel);
    }
}
