package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class BuildingModel {

    @Id
    private Long id;

    // 기존 필드
    private String name;  // 건물 이름
    private String lectureRoomNumber;  // 강의실 번호
    private Double x;  // 위도
    private Double y;  // 경도

    // 추가적인 필드들
    private String buildingName;  // 건물 이름 (중복된 것 같음)
    private String roomNumber;  // 방 번호 (중복될 수 있음)
    private String department;  // 학과

    public BuildingModel() {
    }

    // 필요시 생성자 추가
    public BuildingModel(String name, String lectureRoomNumber, Double x, Double y) {
        this.name = name;
        this.lectureRoomNumber = lectureRoomNumber;
        this.x = x;
        this.y = y;
    }

    // setter 메서드들 추가는 Lombok의 @Setter에 의해 자동 생성됨
}
