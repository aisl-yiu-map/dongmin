package com.example.demo.service;

import com.example.demo.model.BuildingModel;
import com.example.demo.repository.CsvRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CsvService {

    @Autowired
    private CsvRepository buildingRepository;

    public BuildingModel saveBuilding(BuildingModel building) {
        return buildingRepository.save(building);
    }
}
