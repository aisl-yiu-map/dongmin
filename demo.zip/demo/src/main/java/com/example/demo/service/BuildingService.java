package com.example.demo.service;

import com.example.demo.model.BuildingModel;

import org.springframework.stereotype.Service;

@Service
public class BuildingService {
    private final com.example.demo.repository.buildingRepository buildingRepository;

    public BuildingService(com.example.demo.repository.buildingRepository buildingRepository) {
        this.buildingRepository = buildingRepository;
    }

    // 특정 건물 ID로 좌표 및 정보 조회
    public BuildingModel getBuildingById(Long id) {
        return buildingRepository.findById(id).orElseThrow(() -> new RuntimeException("Building not found"));
    }

    // 새로운 건물 정보 저장
    public BuildingModel saveBuilding(BuildingModel buildingModel) {
        return buildingRepository.save(buildingModel);
    }
}
