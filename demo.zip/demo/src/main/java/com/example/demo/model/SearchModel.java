package com.example.demo.model;

public class SearchModel {

    private final String lectureRoomNumber;  // 강의실 번호
    private final String buildingName;       // 건물 이름
    private final Double x;           // 위도
    private final Double y;          // 경도

    public SearchModel(String lectureRoomNumber, String buildingName, Double latitude, Double longitude) {
        this.lectureRoomNumber = lectureRoomNumber;
        this.buildingName = buildingName;
        this.x = latitude;
        this.y = longitude;
    }

    // Getter, Setter 생략
}
