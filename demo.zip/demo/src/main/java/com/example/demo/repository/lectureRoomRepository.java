package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

import com.example.demo.model.LectureRoomModel;

import java.util.Optional;

public interface lectureRoomRepository extends JpaRepository<LectureRoomModel, Long> {
    // 특정 건물에 속한 모든 강의실 조회
    List<LectureRoomModel> findByBuildingId(Long buildingId);

    // 특정 강의실 ID로 조회
    Optional<LectureRoomModel> findById(Long id);
}
