package com.example.demo.controller;

import com.example.demo.model.BuildingModel;
import com.example.demo.service.BuildingService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/buildings")
public class BuildingController {
    private final BuildingService buildingService;

    public BuildingController(BuildingService buildingService) {
        this.buildingService = buildingService;
    }

    // 특정 건물의 정보 및 좌표 조회
    @GetMapping("/{id}")
    public ResponseEntity<BuildingModel> getBuildingById(@PathVariable Long id) {
        return ResponseEntity.ok(buildingService.getBuildingById(id));
    }

    // 새로운 건물 정보 저장
    @PostMapping
    public ResponseEntity<BuildingModel> createBuilding(@RequestBody BuildingModel buildingModel) {
        return ResponseEntity.ok(buildingService.saveBuilding(buildingModel));
    }
}
