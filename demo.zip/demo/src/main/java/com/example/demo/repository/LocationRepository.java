package com.example.demo.repository; // 얜 그냥 기본 좌표 조회용

import com.example.demo.model.LocationModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepository extends JpaRepository<LocationModel, Long> {
    // 기본 CRUD 메서드 제공 (findAll, findById, save, deleteById 등)
}
