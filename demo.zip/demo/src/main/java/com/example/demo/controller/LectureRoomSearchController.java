package com.example.demo.controller;

import com.example.demo.model.LectureRoomModel;
import com.example.demo.model.SearchModel;

import com.example.demo.service.LectureRoomSearchService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/search/lectureroom")
public class LectureRoomSearchController {

    private final LectureRoomSearchService searchService;

    public LectureRoomSearchController(LectureRoomSearchService searchService) {
        this.searchService = searchService;
    }

    @GetMapping("/{lectureRoomNumber}")
    public ResponseEntity<SearchModel> searchLectureRoomByNumber(@PathVariable String lectureRoomNumber) {
        LectureRoomModel lectureRoom = searchService.searchLectureRoomByNumber(lectureRoomNumber);
        if (lectureRoom == null) {
            return ResponseEntity.notFound().build();
        }

        // LectureRoom 정보와 관련된 Building 정보도 함께 반환
        SearchModel searchModel = new SearchModel(
                lectureRoom.getName(),
                lectureRoom.getBuilding().getName(),  // 건물 이름
                lectureRoom.getLatitude(),  // 강의실 위도
                lectureRoom.getLongitude()  // 강의실 경도
        );
        return ResponseEntity.ok(searchModel);
    }
}
