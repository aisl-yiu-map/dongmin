package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class CsvModel {

    @Id
    private Long id;
    private String buildingName;  // 건물 이름
    private String roomNumber;    // 강의실 번호
    private String department;    // 부서 이름

    // 기본 생성자, getter, setter
}
