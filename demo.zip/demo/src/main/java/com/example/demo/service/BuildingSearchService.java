package com.example.demo.service;


import com.example.demo.model.BuildingModel;
import com.example.demo.repository.BuildingSearchRepository;
import org.springframework.stereotype.Service;

@Service
public class BuildingSearchService {

    private final BuildingSearchRepository buildingSearchRepository;

    public BuildingSearchService(BuildingSearchRepository buildingSearchRepository) {
        this.buildingSearchRepository = buildingSearchRepository;
    }

    public BuildingModel searchBuildingByName(String buildingName) {
        return buildingSearchRepository.findByName(buildingName);
    }
}
