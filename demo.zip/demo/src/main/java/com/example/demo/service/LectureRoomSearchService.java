package com.example.demo.service;

import com.example.demo.model.LectureRoomModel;
import com.example.demo.repository.LectureRoomSearchRepository;
import org.springframework.stereotype.Service;

@Service
public class LectureRoomSearchService {

    private final LectureRoomSearchRepository lectureRoomSearchRepository;

    public LectureRoomSearchService(LectureRoomSearchRepository lectureRoomSearchRepository) {
        this.lectureRoomSearchRepository = lectureRoomSearchRepository;
    }

    public LectureRoomModel searchLectureRoomByNumber(String lectureRoomNumber) {
        return lectureRoomSearchRepository.findByLectureRoomNumber(lectureRoomNumber);
    }
}
