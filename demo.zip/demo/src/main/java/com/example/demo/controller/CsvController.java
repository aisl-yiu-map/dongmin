package com.example.demo.controller;

import com.example.demo.model.BuildingModel;
import com.example.demo.service.BuildingService;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStreamReader;
import java.util.Iterator;

@Setter
@Getter
@RestController
@RequestMapping("/api/building")
public class CsvController {

    @Autowired
    private BuildingService buildingService;

    @PostMapping("/upload-csv")
    public String uploadCsvFile(@RequestParam("file") MultipartFile file) {
        try {
            // CSV 파일 읽기
            InputStreamReader reader = new InputStreamReader(file.getInputStream());
            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader());

            Iterator<CSVRecord> records = csvParser.iterator();
            while (records.hasNext()) {
                CSVRecord record = records.next();

                // CSV 데이터에서 필드 읽어오기
                String buildingName = record.get("buildingName");
                String roomNumber = record.get("roomNumber");
                String department = record.get("department");

                // 데이터를 BuildingModel 객체로 변환 후 저장
                BuildingModel building = new BuildingModel();
                building.setBuildingName(buildingName);
                building.setRoomNumber(roomNumber);
                building.setDepartment(department);

                buildingService.saveBuilding(building);
            }
            return "CSV 파일이 성공적으로 업로드되었습니다.";
        } catch (Exception e) {
            return "파일 업로드 중 오류가 발생했습니다.";
        }
    }
}
