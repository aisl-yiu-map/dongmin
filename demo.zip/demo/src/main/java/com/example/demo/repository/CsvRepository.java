package com.example.demo.repository;

import com.example.demo.model.BuildingModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CsvRepository extends JpaRepository<BuildingModel, Long> {
    // 데이터베이스에 Building 모델을 저장하는 기본적인 CRUD 작업을 수행
}
