package com.example.demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.LectureRoomModel;
import com.example.demo.service.LectureRoomService;



import java.util.List;

@RestController
@RequestMapping("/api/lectureRooms")
public class LectureRoomController {
    private final LectureRoomService lectureRoomService;

    public LectureRoomController(LectureRoomService lectureRoomService) {
        this.lectureRoomService = lectureRoomService;
    }

    // 특정 건물에 속한 모든 강의실 조회
    @GetMapping("/building/{buildingId}")
    public ResponseEntity<List<LectureRoomModel>> getLectureRoomsByBuildingId(@PathVariable Long buildingId) {
        return ResponseEntity.ok(lectureRoomService.getLectureRoomsByBuildingId(buildingId));
    }

    // 특정 강의실 ID로 정보 조회
    @GetMapping("/{id}")
    public ResponseEntity<LectureRoomModel> getLectureRoomById(@PathVariable Long id) {
        return ResponseEntity.ok(lectureRoomService.getLectureRoomById(id));
    }

    // 새로운 강의실 정보 저장
    @PostMapping
    public ResponseEntity<LectureRoomModel> createLectureRoom(@RequestBody LectureRoomModel lectureRoomModel) {
        return ResponseEntity.ok(lectureRoomService.saveLectureRoom(lectureRoomModel));
    }
}
