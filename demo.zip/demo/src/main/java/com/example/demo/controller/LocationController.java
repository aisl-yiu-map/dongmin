package com.example.demo.controller; // 얜 그냥 기본 좌표 조회용

import com.example.demo.model.LocationModel;
import com.example.demo.service.LocationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/locations")
public class LocationController {
    private final LocationService locationService;

    public LocationController(LocationService locationService) {
        this.locationService = locationService;
    }

    @GetMapping
    public ResponseEntity<List<LocationModel>> getAllLocations() {
        return ResponseEntity.ok(locationService.getAllLocations());
    }

    @GetMapping("/{id}")
    public ResponseEntity<LocationModel> getLocationById(@PathVariable Long id) {
        return ResponseEntity.ok(locationService.getLocationById(id));
    }

    @PostMapping
    public ResponseEntity<LocationModel> createLocation(@RequestBody LocationModel locationModel) {
        return ResponseEntity.ok(locationService.saveLocation(locationModel));
    }

    @PutMapping("/{id}")
    public ResponseEntity<LocationModel> updateLocation(@PathVariable Long id, @RequestBody LocationModel locationModel) {
        return ResponseEntity.ok(locationService.updateLocation(id, locationModel));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLocation(@PathVariable Long id) {
        locationService.deleteLocation(id);
        return ResponseEntity.noContent().build();
    }
}
