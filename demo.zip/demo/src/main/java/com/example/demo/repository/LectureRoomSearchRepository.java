package com.example.demo.repository;

import com.example.demo.model.LectureRoomModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LectureRoomSearchRepository extends JpaRepository<LectureRoomModel, Long> {

    // 강의실 번호로 검색
    LectureRoomModel findByLectureRoomNumber(String lectureRoomNumber);
}
