package com.example.demo.repository;

import com.example.demo.model.BuildingModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BuildingSearchRepository extends JpaRepository<BuildingModel, Long> {

    // 건물 이름으로 검색
    BuildingModel findByName(String name);
}
